import { Factory, Sprout, Cpu, Rocket } from 'lucide-react'
import data from '../../data/activities.json'
import Review from '../ui/Review.jsx'

const icons = [Factory, Sprout, Cpu, Rocket]

export default function WhatWeDo() {
  return (
    <section className="container-page mt-24">
      <h2 data-node="Focus" className="text-3xl font-bold">What we work on {data.review && <Review note="Titles come from your text and banner. Descriptions are drafts. Edit src/data/activities.json." />}</h2>
      <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {data.items.map((a, i) => {
          const Icon = icons[i % icons.length]
          return (
            <li key={a.title} className="card">
              <span className="gem"><Icon size={26} /></span>
              <h3 className="mt-5 text-xl font-bold">{a.title}</h3>
              <p className="mt-2 opacity-80">{a.text}</p>
            </li>
          )
        })}
      </ul>
    </section>
  )
}
